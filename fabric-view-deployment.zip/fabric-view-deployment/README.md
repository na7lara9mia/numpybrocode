# Fabric view deployment pipeline

Copy `azure-pipelines.yml` and `cicd/` to the **root** of your Azure DevOps repository. Create/verify the `fabric-views-deploy` variable group containing `tenant_id`, `client_id`, secret `client_secret`, `dev_workspace_id`, `dev_exportnotebook_id`, `dev_workspace_name`, `rec_lakehouse_name`, and `rec_warehouse_server`. Authorize the pipeline to use that group. Set `targetBranch` to an existing branch. Run the pipeline manually.

The flow runs and monitors the DEV export notebook, downloads `Files/deploy/views/**/*.sql` from the configured DEV Lakehouse, commits those files to the target branch, then deploys them to the REC Warehouse. The target branch must also contain the `cicd/scripts/` files. The source notebook must have `tenant_id`, `client_id`, and `client_secret` parameters and write view DDLs to the expected OneLake folder.

**Check the naming:** the original configuration uses `rec_lakehouse_name` for both the *DEV export Lakehouse* and the *REC Warehouse database*. Keep it only if those names really match; otherwise point `DEV_LAKEHOUSE_NAME` and `REC_WAREHOUSE_DATABASE` to separate variable-group entries.

The service principal needs Fabric notebook and DEV OneLake read access, REC Warehouse DDL permissions, and the pipeline identity needs repository push permissions. DDL files should each contain a single executable SQL statement; deployment is in lexical filename order. The script does not parse `GO` batches or infer dependencies. Fabric does not guarantee an all-or-nothing deployment across view files; fix failures and rerun. Do not log notebook request bodies or tokens.
