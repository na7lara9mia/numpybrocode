param([Parameter(Mandatory)][string]$Branch)
$ErrorActionPreference = 'Stop'
Set-Location $env:BUILD_SOURCESDIRECTORY
if (-not @(Get-ChildItem 'cicd/deploy/views' -Filter '*.sql' -File -Recurse -ErrorAction SilentlyContinue).Count) { throw 'No SQL files to commit.' }
git config user.email 'fhabib_ext@gsf.fr'
git config user.name 'HABIB Fouad'
git add --all -- cicd/deploy/views
if ($LASTEXITCODE -ne 0) { throw 'git add failed.' }
git diff --cached --quiet
if ($LASTEXITCODE -eq 0) { Write-Host 'No DDL changes detected.'; exit 0 }
if ($LASTEXITCODE -ne 1) { throw 'git diff failed.' }
git commit -m 'Refresh Warehouse view DDLs [skip ci]'
if ($LASTEXITCODE -ne 0) { throw 'git commit failed.' }
git push origin "HEAD:refs/heads/$Branch"
if ($LASTEXITCODE -ne 0) { throw 'git push failed.' }
