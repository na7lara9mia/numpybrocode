"""Export DEV Warehouse view definitions directly into repository SQL files."""
import hashlib
import os
import re
import shutil
import struct
import tempfile
from pathlib import Path

import pyodbc
from azure.identity import ClientSecretCredential

INCLUDED_SCHEMAS = {"dbo"}
EXCLUDED_SCHEMAS = {"sys", "information_schema"}


def required(name):
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing variable: {name}")
    return value


def sanitize_file_part(value):
    sanitized = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")
    if not sanitized:
        raise ValueError(f"Cannot form filename for SQL identifier: {value!r}")
    return sanitized


def normalize_view_ddl(definition):
    if not definition or not definition.strip():
        raise ValueError("The view definition is empty.")
    ddl, count = re.subn(
        r"^\s*(?:CREATE\s+(?:OR\s+ALTER\s+)?|ALTER\s+)VIEW\b",
        "CREATE OR ALTER VIEW",
        definition.strip(),
        count=1,
        flags=re.IGNORECASE,
    )
    if count != 1:
        raise ValueError("View definition must begin with CREATE VIEW or ALTER VIEW.")
    ddl = ddl.rstrip()
    return (ddl if ddl.endswith(";") else ddl + ";") + "\n"


def main():
    tenant = required("TENANT_ID")
    client = required("CLIENT_ID")
    secret = required("CLIENT_SECRET")
    server = required("DEV_WAREHOUSE_SERVER")
    database = required("DEV_WAREHOUSE_DATABASE")
    folder = Path(required("DDL_FOLDER"))

    credential = ClientSecretCredential(tenant_id=tenant, client_id=client, client_secret=secret)
    access_token = credential.get_token("https://database.windows.net/.default").token
    encoded = access_token.encode("utf-16-le")
    token_struct = struct.pack(f"<I{len(encoded)}s", len(encoded), encoded)
    driver = next((d for d in ("ODBC Driver 18 for SQL Server", "ODBC Driver 17 for SQL Server") if d in pyodbc.drivers()), None)
    if driver is None:
        raise RuntimeError(f"SQL Server ODBC driver not found: {pyodbc.drivers()}")
    connection_string = (
        f"Driver={{{driver}}};Server={server},1433;Database={database};"
        "Encrypt=Yes;TrustServerCertificate=No;Connection Timeout=30;"
    )
    query = """
        SELECT s.name AS schema_name, v.name AS view_name, m.definition AS view_definition
        FROM sys.views AS v
        JOIN sys.schemas AS s ON s.schema_id = v.schema_id
        JOIN sys.sql_modules AS m ON m.object_id = v.object_id
        WHERE v.is_ms_shipped = 0 AND s.name NOT IN ('sys', 'INFORMATION_SCHEMA')
        ORDER BY s.name, v.name
    """
    with pyodbc.connect(connection_string, attrs_before={1256: token_struct}, autocommit=True) as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        views = cursor.fetchall()

    prepared = []
    for schema, view_name, definition in views:
        if (INCLUDED_SCHEMAS and schema.lower() not in INCLUDED_SCHEMAS) or schema.lower() in EXCLUDED_SCHEMAS:
            continue
        filename = f"{sanitize_file_part(schema)}.{sanitize_file_part(view_name)}.sql"
        prepared.append((filename, normalize_view_ddl(definition)))
    if not prepared:
        raise RuntimeError("No views matched the schema filters; existing DDLs were preserved.")
    if len({filename.lower() for filename, _ in prepared}) != len(prepared):
        raise RuntimeError("View filenames collide after sanitization; existing DDLs were preserved.")

    folder.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix="views-export-", dir=folder.parent))
    try:
        for filename, ddl in prepared:
            (staging / filename).write_text(ddl, encoding="utf-8", newline="\n")
            print(f"Exported {filename}: {hashlib.sha256(ddl.encode('utf-8')).hexdigest()}")
        # Validate all files before replacing the previously checked-out view set.
        if len(list(staging.glob("*.sql"))) != len(prepared):
            raise RuntimeError("Export validation failed.")
        if folder.exists():
            shutil.rmtree(folder)
        staging.rename(folder)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    print(f"Export completed: {len(prepared)} SQL file(s) from {database}.")


if __name__ == "__main__":
    main()
