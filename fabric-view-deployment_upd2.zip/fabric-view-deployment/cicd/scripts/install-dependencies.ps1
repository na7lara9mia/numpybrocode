$ErrorActionPreference = 'Stop'
python -m pip install --disable-pip-version-check -r (Join-Path $env:BUILD_SOURCESDIRECTORY 'cicd/scripts/requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
