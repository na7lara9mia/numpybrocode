param([Parameter(Mandatory)][string]$Branch, [switch]$RequireSqlFiles)
$ErrorActionPreference = 'Stop'
$source = $env:BUILD_SOURCESDIRECTORY
if (-not $source) { throw 'BUILD_SOURCESDIRECTORY is missing.' }
Set-Location $source
git fetch origin -- $Branch
if ($LASTEXITCODE -ne 0) { throw 'git fetch failed.' }
git checkout -B $Branch "origin/$Branch"
if ($LASTEXITCODE -ne 0) { throw 'git checkout failed.' }
if ($RequireSqlFiles) {
    $folder = Join-Path $source 'cicd/deploy/views'
    $files = @(Get-ChildItem -Path $folder -Filter '*.sql' -File -Recurse -ErrorAction SilentlyContinue)
    if ($files.Count -eq 0) { throw 'No committed SQL files were found for REC deployment.' }
    Write-Host "Found $($files.Count) committed SQL file(s)."
}
