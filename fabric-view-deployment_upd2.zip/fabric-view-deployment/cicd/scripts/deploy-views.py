"""Deploy SQL view definitions from the target branch to a Fabric Warehouse."""
import os
import struct
from pathlib import Path

import pyodbc
from azure.identity import ClientSecretCredential


def required(name):
    value = os.environ.get(name, '').strip()
    if not value:
        raise RuntimeError(f'Missing variable: {name}')
    return value


def main():
    tenant = required('TENANT_ID')
    client = required('CLIENT_ID')
    secret = required('CLIENT_SECRET')
    server = required('REC_WAREHOUSE_SERVER')
    database = required('REC_WAREHOUSE_DATABASE')
    folder = Path(required('DDL_FOLDER'))
    files = sorted(folder.rglob('*.sql'))
    if not files:
        raise RuntimeError(f'No SQL files found under {folder}')

    credential = ClientSecretCredential(tenant_id=tenant, client_id=client, client_secret=secret)
    token = credential.get_token('https://database.windows.net/.default').token.encode('utf-16-le')
    packed_token = struct.pack(f'<I{len(token)}s', len(token), token)
    driver = next((d for d in ('ODBC Driver 18 for SQL Server', 'ODBC Driver 17 for SQL Server') if d in pyodbc.drivers()), None)
    if driver is None:
        raise RuntimeError(f'SQL Server ODBC driver not found. Installed drivers: {pyodbc.drivers()}')
    connection_string = (
        f'Driver={{{driver}}};Server={server},1433;Database={database};'
        'Encrypt=Yes;TrustServerCertificate=No;Connection Timeout=30;'
    )
    with pyodbc.connect(connection_string, attrs_before={1256: packed_token}, autocommit=True) as conn:
        cursor = conn.cursor()
        for index, path in enumerate(files, start=1):
            ddl = path.read_text(encoding='utf-8-sig').strip()
            if not ddl:
                raise RuntimeError(f'Empty SQL file: {path}')
            print(f'Deploying [{index}/{len(files)}] {path.relative_to(folder)}', flush=True)
            cursor.execute(ddl)
    print(f'Deployment completed: {len(files)} SQL file(s).', flush=True)


if __name__ == '__main__':
    main()
