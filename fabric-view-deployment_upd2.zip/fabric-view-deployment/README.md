# Fabric view DDL export and deployment

Copy `azure-pipelines.yml` and `cicd/` to the root of your Azure DevOps repository, including the scripts on the existing `targetBranch`. Run the pipeline manually.

The first stage checks out the target branch, runs `cicd/scripts/export-views.py` on the Windows agent to query the DEV Warehouse, writes `cicd/deploy/views/*.sql` locally, and commits those files. The second stage checks out the latest target branch and runs `deploy-views.py` against the REC Warehouse. No Fabric notebook or OneLake intermediate storage is used.

Configure and authorize variable group `fabric-views-deploy` with `tenant_id`, `client_id`, secret `client_secret`, `dev_warehouse_server`, `dev_warehouse_database`, `rec_warehouse_server`, and `rec_lakehouse_name` (used as REC Warehouse database). The identity must be able to read DEV Warehouse view definitions and create or alter views in REC; the build identity needs permission to push to `targetBranch`.

The export filters to the `dbo` schema; change `INCLUDED_SCHEMAS` in `export-views.py` if needed. The deployment sorts files by filename; each SQL file must be one executable statement with no `GO` separators. View dependency order and transactional rollback across multiple files are not provided.
