$ErrorActionPreference = 'Stop'
foreach ($name in @('TENANT_ID', 'CLIENT_ID', 'CLIENT_SECRET', 'DEV_WORKSPACE_ID', 'DEV_EXPORT_NOTEBOOK_ID', 'DEV_WAREHOUSE_SERVER', 'DEV_WAREHOUSE_DATABASE')) {
    if ([string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable($name))) { throw "Missing $name" }
}
$tenantId = $env:TENANT_ID
$auth = Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -ContentType 'application/x-www-form-urlencoded' -Body @{
    client_id = $env:CLIENT_ID; client_secret = $env:CLIENT_SECRET
    scope = 'https://analysis.windows.net/powerbi/api/.default'; grant_type = 'client_credentials'
}
$headers = @{ Authorization = "Bearer $($auth.access_token)" }
$runUri = "https://api.fabric.microsoft.com/v1/workspaces/$($env:DEV_WORKSPACE_ID)/notebooks/$($env:DEV_EXPORT_NOTEBOOK_ID)/jobs/execute/instances?beta=false"
$body = @{ parameters = @(
    @{ name = 'warehouse_server'; value = $env:DEV_WAREHOUSE_SERVER; type = 'Text' },
    @{ name = 'warehouse_database'; value = $env:DEV_WAREHOUSE_DATABASE; type = 'Text' },
    @{ name = 'tenant_id'; value = $tenantId; type = 'Text' },
    @{ name = 'client_id'; value = $env:CLIENT_ID; type = 'Text' },
    @{ name = 'client_secret'; value = $env:CLIENT_SECRET; type = 'Text' }
); executionData = @{ compute = 'Spark' } } | ConvertTo-Json -Depth 10
$response = Invoke-WebRequest -Method Post -Uri $runUri -Headers $headers -ContentType 'application/json' -Body $body
$pollUri = [string]$response.Headers['Location']
if (-not $pollUri -or -not $pollUri.StartsWith('https://api.fabric.microsoft.com/')) { throw 'Notebook start response has no valid Location header.' }
Write-Host 'Export notebook started.'
$deadline = (Get-Date).AddMinutes(105)
while ((Get-Date) -lt $deadline) {
    $delay = 20
    if ($response.Headers['Retry-After']) { $delay = [Math]::Max(1, [int]$response.Headers['Retry-After']) }
    Start-Sleep -Seconds $delay
    $response = Invoke-WebRequest -Method Get -Uri $pollUri -Headers $headers
    $job = $response.Content | ConvertFrom-Json
    Write-Host "Export notebook status: $($job.status)"
    if ($job.status -eq 'Completed') { exit 0 }
    if ($job.status -in @('Failed', 'Cancelled', 'Canceled', 'Deduped')) { throw "Notebook export ended with status $($job.status): $($job.failureReason | ConvertTo-Json -Compress -Depth 5)" }
}
throw 'Export notebook timed out.'
