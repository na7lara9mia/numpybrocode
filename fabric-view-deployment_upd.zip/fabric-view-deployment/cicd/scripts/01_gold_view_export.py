# Fabric notebook: 01_gold_view_export
# Put the variables in this first section in a Fabric notebook parameter cell.
# The job API overrides them at runtime.
warehouse_server = ""
warehouse_database = ""
tenant_id = ""
client_id = ""
client_secret = ""

# The DEV Lakehouse containing Files/deploy/views must be attached as default.
output_folder = "file:/lakehouse/default/Files/deploy/views"
included_schemas = ["dbo"]
excluded_schemas = ["sys", "INFORMATION_SCHEMA"]

# End of parameter cell. The remaining code belongs in the next Python cell.
import hashlib
import json
import os
import re
import struct
from datetime import datetime, timezone

import pyodbc
from azure.identity import ClientSecretCredential
from notebookutils import mssparkutils

for parameter_name in ("warehouse_server", "warehouse_database", "tenant_id", "client_id", "client_secret"):
    if not str(globals().get(parameter_name, "")).strip():
        raise ValueError(f"Missing required notebook parameter: {parameter_name}")

warehouse_server = warehouse_server.strip()
warehouse_database = warehouse_database.strip()
print(f"Source Warehouse: {warehouse_database}")
print(f"SQL endpoint: {warehouse_server}")
print(f"Output folder: {output_folder}")

credential = ClientSecretCredential(tenant_id=tenant_id, client_id=client_id, client_secret=client_secret)
access_token = credential.get_token("https://database.windows.net/.default").token
if not access_token:
    raise RuntimeError("The Microsoft Entra access token is empty.")
token_bytes = access_token.encode("utf-16-le")
token_struct = struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)
odbc_driver = next((driver for driver in ("ODBC Driver 18 for SQL Server", "ODBC Driver 17 for SQL Server") if driver in pyodbc.drivers()), None)
if not odbc_driver:
    raise RuntimeError(f"No supported SQL Server ODBC driver found: {pyodbc.drivers()}")
connection_string = (
    f"Driver={{{odbc_driver}}};Server={warehouse_server},1433;Database={warehouse_database};"
    "Encrypt=Yes;TrustServerCertificate=No;Connection Timeout=30;"
)

extract_query = """
SELECT s.name AS schema_name, v.name AS view_name, m.definition AS view_definition
FROM sys.views AS v
JOIN sys.schemas AS s ON s.schema_id = v.schema_id
JOIN sys.sql_modules AS m ON m.object_id = v.object_id
WHERE v.is_ms_shipped = 0 AND s.name NOT IN ('sys', 'INFORMATION_SCHEMA')
ORDER BY s.name, v.name
"""
with pyodbc.connect(connection_string, attrs_before={1256: token_struct}, autocommit=True) as connection:
    cursor = connection.cursor()
    cursor.execute(extract_query)
    columns = [column[0] for column in cursor.description]
    views = [dict(zip(columns, row)) for row in cursor.fetchall()]

include = {schema.lower() for schema in included_schemas}
exclude = {schema.lower() for schema in excluded_schemas}
views = [view for view in views if (not include or view["schema_name"].lower() in include) and view["schema_name"].lower() not in exclude]
if not views:
    raise RuntimeError("No views matched the schema filters; export stopped to preserve existing DDLs.")
print(f"Views retained after filtering: {len(views)}")


def sanitize_file_part(value):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")


def normalize_view_ddl(definition):
    if not definition or not definition.strip():
        raise ValueError("The view definition is empty.")
    ddl, count = re.subn(r"^\s*(?:CREATE\s+(?:OR\s+ALTER\s+)?|ALTER\s+)VIEW\b", "CREATE OR ALTER VIEW", definition.strip(), count=1, flags=re.IGNORECASE)
    if count != 1:
        raise ValueError("The module definition does not start with CREATE VIEW or ALTER VIEW.")
    ddl = ddl.rstrip()
    return (ddl if ddl.endswith(";") else ddl + ";") + "\n"


prepared = []
for view in views:
    name = f"{sanitize_file_part(view['schema_name'])}.{sanitize_file_part(view['view_name'])}.sql"
    prepared.append((name, normalize_view_ddl(view["view_definition"]), view))
if len({name.lower() for name, _, _ in prepared}) != len(prepared):
    raise RuntimeError("View filenames collide after sanitization; export stopped.")

# Validate definitions before replacing the prior output directory.
if mssparkutils.fs.exists(output_folder):
    mssparkutils.fs.rm(output_folder, recurse=True)
mssparkutils.fs.mkdirs(output_folder)
local_folder = output_folder.removeprefix("file:")
manifest = []
for name, ddl, view in prepared:
    path = os.path.join(local_folder, name)
    with open(path, "w", encoding="utf-8", newline="\n") as file:
        file.write(ddl)
    manifest.append({
        "schema_name": view["schema_name"], "view_name": view["view_name"],
        "file_name": name, "sha256": hashlib.sha256(ddl.encode("utf-8")).hexdigest(),
    })
    print(f"Exported [{view['schema_name']}].[{view['view_name']}] to {name}")
sql_files = sorted(item.name for item in mssparkutils.fs.ls(output_folder) if item.name.lower().endswith(".sql"))
if len(sql_files) != len(prepared):
    raise RuntimeError(f"Export validation failed: expected {len(prepared)} SQL files, found {len(sql_files)}.")
with open(os.path.join(local_folder, "_manifest.json"), "w", encoding="utf-8", newline="\n") as file:
    json.dump({
        "source": {"warehouse_server": warehouse_server, "warehouse_database": warehouse_database},
        "exported_at_utc": datetime.now(timezone.utc).isoformat(),
        "view_count": len(manifest), "views": manifest,
    }, file, indent=2, ensure_ascii=False)
print(f"View DDL export completed: {len(sql_files)} SQL files.")
