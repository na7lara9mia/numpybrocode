$ErrorActionPreference = 'Stop'
foreach ($name in @('TENANT_ID', 'CLIENT_ID', 'CLIENT_SECRET', 'DEV_WORKSPACE_NAME', 'DEV_LAKEHOUSE_NAME', 'DDL_FOLDER')) {
    if ([string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable($name))) { throw "Missing $name" }
}
$auth = Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$($env:TENANT_ID)/oauth2/v2.0/token" -ContentType 'application/x-www-form-urlencoded' -Body @{
    client_id = $env:CLIENT_ID; client_secret = $env:CLIENT_SECRET
    scope = 'https://storage.azure.com/.default'; grant_type = 'client_credentials'
}
$headers = @{ Authorization = "Bearer $($auth.access_token)"; 'x-ms-version' = '2023-08-03' }
$workspace = [uri]::EscapeDataString($env:DEV_WORKSPACE_NAME)
$prefix = "$($env:DEV_LAKEHOUSE_NAME).lakehouse/Files/deploy/views"
$base = "https://onelake.dfs.fabric.microsoft.com/$workspace"
$paths = [System.Collections.Generic.List[string]]::new()
$continuation = $null
do {
    $listUri = "$base`?resource=filesystem&directory=$([uri]::EscapeDataString($prefix))&recursive=true"
    if ($continuation) { $listUri += "&continuation=$([uri]::EscapeDataString($continuation))" }
    $response = Invoke-WebRequest -Method Get -Uri $listUri -Headers $headers
    $listing = $response.Content | ConvertFrom-Json
    foreach ($item in $listing.paths) {
        if ($item.isDirectory -eq $true -or $item.isDirectory -eq 'true') { continue }
        if (-not $item.name.EndsWith('.sql', [System.StringComparison]::OrdinalIgnoreCase)) { continue }
        if (-not $item.name.StartsWith("$prefix/", [System.StringComparison]::Ordinal)) { throw 'Unexpected OneLake path.' }
        $paths.Add([string]$item.name)
    }
    $continuation = [string]$response.Headers['x-ms-continuation']
} while ($continuation)
if ($paths.Count -eq 0) { throw "No SQL files found in $prefix; existing DDLs were preserved." }
$folder = [System.IO.Path]::GetFullPath($env:DDL_FOLDER)
$staging = "$folder.download-$([guid]::NewGuid().ToString('N'))"
New-Item -ItemType Directory -Path $staging -Force | Out-Null
try {
    foreach ($path in $paths) {
        $relative = $path.Substring($prefix.Length + 1)
        $parts = $relative -split '/'
        if ($parts | Where-Object { $_ -in @('', '.', '..') -or $_.Contains('\') }) { throw "Unsafe path in listing: $path" }
        $target = Join-Path $staging ([System.IO.Path]::Combine([string[]]$parts))
        New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
        $fileUri = "$base/$((($path -split '/') | ForEach-Object { [uri]::EscapeDataString($_) }) -join '/')"
        Invoke-WebRequest -Method Get -Uri $fileUri -Headers $headers -OutFile $target
        Write-Host "Downloaded $relative"
    }
    if (Test-Path $folder) { Remove-Item $folder -Recurse -Force }
    Move-Item $staging $folder
} finally {
    if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
}
Write-Host "Downloaded $($paths.Count) SQL file(s)."
